from src.nitrado.nitrado_api import NitradoAPI
from src.nitrado.service import Service
from src.nitrado.game_server import GameServer
from src.nitrado.client import Client


def initialize_client(url=None, key=None):
    NitradoAPI.initialize_client(url, key)

